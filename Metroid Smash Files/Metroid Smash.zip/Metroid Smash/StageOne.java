//Matas Empakeris, Period 5

 import javax.swing.*;
 import java.awt.*;
 import java.awt.event.*;
 import java.util.ArrayList;

 public class StageOne extends Map
   {
   private static StageOneGround ground;
   private StageOnePlatformGeneric platformGenericBottom;
   private StageOnePlatformGeneric platformGenericTop;
   private StageOnePlatformLeftBottom platformLeftBottom;
   private StageOnePlatformLeftTop platformLeftTop;
   
   private ArrayList< LevelObject > levelObjects; //contains all objects in the level. Used for collision detection
   private ArrayList< LevelObject > notTouching;
   
   private Timer timer; //refresh rate set in constructor
   private int notColliding;
   
   
   public StageOne()
      {
      ground = new StageOneGround( -5, 837 );
      this.setMinimumY( ground.getY() );
      
      platformGenericBottom = new StageOnePlatformGeneric( 532, 649 );
      platformGenericTop = new StageOnePlatformGeneric( ( int ) 300, 400 );
      platformLeftBottom = new StageOnePlatformLeftBottom( 132, 649 );
      platformLeftTop = new StageOnePlatformLeftTop( 100, 586 );
      
      this.getCurrentCharacter().setY( ground.getY() - this.getCurrentCharacter().getHeight() );
      
      levelObjects = new ArrayList< LevelObject >();
      notTouching = new ArrayList< LevelObject >();
      levelObjects.add( platformGenericBottom );
      levelObjects.add( platformGenericTop );
      levelObjects.add( platformLeftBottom );
      levelObjects.add( platformLeftTop );
      levelObjects.add( ground );
      
      this.setBackgroundImage( "level_background_1.png" );
      
      timer = new Timer( 27, this ); //default: 27
      timer.start();
      } //end Stage_One()
      
   //returns the stage's ground for use in other classes
      
   final public static StageOneGround getGround()
      {
      return ground;
      } //end getGround()
      
   public void paintComponent( Graphics g )
      {
      Graphics2D g2d = ( Graphics2D ) g;

      super.paintComponent( g2d );
      
      g2d.drawImage( platformGenericBottom.getStates().get( 0 ), platformGenericBottom.getX(), platformGenericBottom.getY(), null );
      g2d.drawImage( platformGenericTop.getStates().get( 0 ), platformGenericTop.getX(), platformGenericTop.getY(), null );
      g2d.drawImage( platformLeftBottom.getStates().get( 0 ), platformLeftBottom.getX(), platformLeftBottom.getY(), null );
      g2d.drawImage( platformLeftTop.getStates().get( 0 ), platformLeftTop.getX(), platformLeftTop.getY(), null );
      
      g2d.drawImage( ground.getStates().get( 0 ), 0, 837, null ); //0,837
      } //end paintComponent()
      
   public void actionPerformed( ActionEvent e )
      {
      super.actionPerformed( e );
      
      if( this.getCurrentCharacter().isDead() == false )
         {
         for( LevelObject o: levelObjects )
            {
            this.getCurrentCharacter().checkCollision( o, this.getCurrentCharacter() );
        
            if( o.getIsTouchingSurfaceObject() == false && this.getCurrentCharacter().getYTrigger() == false )
              {
              notTouching.add( o );
              } //end if
            } //end for
        
         if( notTouching.size() == levelObjects.size() && this.getCurrentCharacter().isDead() == false )
            {
            this.getCurrentCharacter().setChangeY( this.getCurrentCharacter().getChangeY() + 3 );
            this.getCurrentCharacter().setY( this.getCurrentCharacter().getChangeY() + this.getCurrentCharacter().getY() );
            notTouching.clear();
            } //end if
         
           else
              {
              notTouching.clear();
              } //end else
         } //end if
      } //end actionPerformed()
   } //end Stage_One